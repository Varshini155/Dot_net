﻿namespace HolidayProjectAPI
{
    public class Product
    {
        public  int id { get; set; }
        public string name  { get; set; }
        public double cost { get; set; } 

    }
}
