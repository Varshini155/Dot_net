﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcOld.Models
{
    public class Movie
    {
        public string MovieName { get; set; }
        public double Ratings { get; set; }
        public int id { get; set; }
    }
}